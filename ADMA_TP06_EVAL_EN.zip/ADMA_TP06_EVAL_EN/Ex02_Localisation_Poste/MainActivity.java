package radio.com.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    private Button btnAjoutGouv;
    private Button btnAjoutBureau;
    private Button btnRechercheBureau;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        init();
    }

    private void init() {
        btnAjoutGouv=findViewById(R.id.btnAjoutGouv);
        btnAjoutBureau=findViewById(R.id.btnAjoutBureau);
        btnRechercheBureau=findViewById(R.id.btnRechercheBureau);
        ajouterEcouteurs();
    }

    private void ajouterEcouteurs() {
        btnAjoutGouv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ajouterGouv();
            }
        });
        btnAjoutBureau.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ajouterBureau();
            }
        });
        btnRechercheBureau.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                rechercherBureau();
            }
        });
    }

    private void ajouterGouv() {
        Intent i = new Intent(this,AjoutGouv.class);
        startActivity(i);
    }

    private void ajouterBureau() {
        Intent i = new Intent(this,AjoutBureau.class);
        startActivity(i);
    }

    private void rechercherBureau() {
        Intent i = new Intent(this,RechercheBureau.class);
        startActivity(i);
    }




}
