package radio.com.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

public class AjoutBureau extends AppCompatActivity {
    private Spinner spGouv;
    private ArrayAdapter<String> adpGouv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ajout_bureau);
        init();
    }

    private void init() {
        spGouv=findViewById(R.id.spGouv);
        adpGouv=new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item);
        spGouv.setAdapter(adpGouv);
        adpGouv.add("Sfax");
    }
}
