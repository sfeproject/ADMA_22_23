package radio.com.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class AjoutGouv extends AppCompatActivity {
    private EditText edNom;
    private EditText edLat;
    private EditText edLong;
    private Button btnAjouter;
    private Button btnAnnuler;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ajout_gouv);
        init();
    }

    private void init() {
        edNom=findViewById(R.id.edNom);
        edLat=findViewById(R.id.edLat);
        edLong=findViewById(R.id.edLong);
        btnAjouter=findViewById(R.id.btnAjouter);
        btnAnnuler=findViewById(R.id.btnAnnuler);
        ajouterEcouteur();
    }

    private void ajouterEcouteur() {
        btnAjouter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ajouter();
            }
        });
        btnAnnuler.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                annuler();
            }
        });
    }

    private void ajouter() {
    }
    private void annuler() {
    }
}
