package radio.com.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.SeekBar;

public class Modification extends AppCompatActivity {
    private EditText edId;
    private EditText edNom;
    private SeekBar seekAvn;
    private Button btnModifier;
    private Button btnAnnuler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_modification);
        init();
    }

    private void init() {
        edId=findViewById(R.id.edId);
        edNom=findViewById(R.id.edNom);
        seekAvn=findViewById(R.id.seekAvn);
        btnModifier=findViewById(R.id.btnModifier);
        btnAnnuler=findViewById(R.id.btnAnnuler);
        ajouterEcouteurs();
        actualiser();
    }

    private void actualiser() {
        edId.setText(getIntent().getIntExtra("id",0)+"");
        edNom.setText(getIntent().getStringExtra("nom"));
        seekAvn.setProgress(getIntent().getIntExtra("avn",0));
    }

    private void ajouterEcouteurs() {
        btnModifier.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                modifier();
            }
        });
        btnAnnuler.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                annuler();
            }
        });

    }

    private void modifier() {
        
    }
    private void annuler() {
       
    }
}
