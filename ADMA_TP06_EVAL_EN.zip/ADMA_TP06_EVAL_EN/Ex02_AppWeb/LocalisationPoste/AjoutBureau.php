<?php
	if (isset($_REQUEST['nom']) && isset($_REQUEST['cp'])&& isset($_REQUEST['lat'])&& isset($_REQUEST['lon'])&& isset($_REQUEST['nomGouv'])) {
		$nom = $_REQUEST['nom'];
		$cp = $_REQUEST['cp'];
		$lat = $_REQUEST['lat'];
		$lon = $_REQUEST['lon'];
		$nomGouv = $_REQUEST['nomGouv'];
		// include db handler
		require_once './db/DB_Functions.php';
		$db = new DB_Functions();
		$db->ajouterBureau($nom, $cp,$lat,$lon,$nomGouv);
		$reponse=array();
		$reponse["ETAT"]="SUCCES";
		
		echo json_encode($reponse);
	
	} else {
		$reponse=array();
		$reponse["ETAT"]="ECHEC";
		echo json_encode($reponse);		
	}
?>