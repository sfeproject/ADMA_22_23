package com.guide;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;



import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;

public class Recherche extends Activity {
	private Spinner spType;
	private EditText edRoute;
	private Button btnRechercher;
	private ListView lstPharmacie;
	private ArrayAdapter<String> adpType;
	private ArrayAdapter<Pharmacie> adpPharmacie;

	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.recherche);
		init();
	}

	private void init() {
		spType = (Spinner) findViewById(R.id.spType1);
		edRoute = (EditText) findViewById(R.id.edRoute1);
		btnRechercher = (Button) findViewById(R.id.btnRechercher);
		lstPharmacie = (ListView) findViewById(R.id.lstPharmacie);

		adpType = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item);
		adpType.add("Jour");
		adpType.add("Nuit");
		adpType.add("Garde");
		spType.setAdapter(adpType);

		adpPharmacie=new ArrayAdapter<Pharmacie>(this, android.R.layout.simple_list_item_1);
		lstPharmacie.setAdapter(adpPharmacie);
		ajouterEcouteur();
	}

	private void ajouterEcouteur() {
		
	}

	protected void rechercher() {
		
	}
	
}