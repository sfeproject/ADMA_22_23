<?php
	if (isset($_POST['nom']) && isset($_POST['type'])&& isset($_POST['route'])&& isset($_POST['dcv'])) {
		$nom = $_POST['nom'];
		$type = $_POST['type'];
		$route = $_POST['route'];
		$dcv = $_POST['dcv'];
		// include db handler
		require_once '../db/DB_Functions.php';
		$db = new DB_Functions();
		$db->ajouterPharmacie($nom, $type,$route,$dcv);
		$reponse=array();
		$reponse["ETAT"]="SUCCES";
		
		echo json_encode($reponse);
	
	} else {
		$reponse=array();
		$reponse["ETAT"]="ECHEC";
		echo json_encode($reponse);		
	}
?>