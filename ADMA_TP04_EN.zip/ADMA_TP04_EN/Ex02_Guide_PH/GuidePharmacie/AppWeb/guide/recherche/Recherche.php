<?php
	


if ( isset($_POST['type'])&& isset($_POST['route'])) {
		$type = $_POST['type'];
		$route = $_POST['route'];
		// include db handler
		require_once '../db/DB_Functions.php';
		$db = new DB_Functions();
		$db->rechercherPharmacie($type,$route);
		
	
	} else {
		$reponse=array();
		$reponse["ETAT"]="ECHEC";
		echo json_encode($reponse);		
	}	
?>	
