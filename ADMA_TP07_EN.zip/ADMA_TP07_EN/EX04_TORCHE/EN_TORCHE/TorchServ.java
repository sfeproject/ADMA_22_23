package radio.com.mytorch;

import android.annotation.SuppressLint;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.hardware.Camera;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.os.IBinder;
import android.os.PowerManager;
import android.util.Log;
import android.widget.CompoundButton;

import androidx.annotation.Nullable;

import static java.lang.Thread.sleep;

public class TorchServ extends Service implements SensorEventListener {
    public static final double NORME_MODIF=15;
    private boolean isLighOn;
    PowerManager pm;
    PowerManager.WakeLock wl;
    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    private Camera camera;
    Camera.Parameters p;
  

    @Override
    public void onCreate() {
        super.onCreate();
        init();
    }



    private void init() {

      

        Context context = this;
        PackageManager pm = context.getPackageManager();

        // if device support camera?
        if (!pm.hasSystemFeature(PackageManager.FEATURE_CAMERA)) {
            Log.e("err", "Device has no camera!");
            return;
        }

        camera = Camera.open();
        p = camera.getParameters();
       

        
    }



    private void onOff(boolean isChecked) {
        if (isChecked) {
            Log.i("info", "torch is turn on!");

            p.setFlashMode(Camera.Parameters.FLASH_MODE_TORCH);

            camera.setParameters(p);
            camera.startPreview();
           isLighOn = true;


        } else {
            Log.i("info", "torch is turn off!");

            p.setFlashMode(Camera.Parameters.FLASH_MODE_OFF);
            camera.setParameters(p);
            camera.stopPreview();
            isLighOn = false;



        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        mg.unregisterListener(this,acc);
        if (camera != null) {
            onOff(false);
            camera.release();
        }
    }




    @SuppressLint("InvalidWakeLockTag")
    @Override
    public void onSensorChanged(SensorEvent event) {
        
        

            //pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
            //wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK,"satish");

            //wl.acquire();
            
            //wl.release();

           
        

    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }
}
