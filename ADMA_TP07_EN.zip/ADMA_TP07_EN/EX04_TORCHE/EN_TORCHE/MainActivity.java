package radio.com.mytorch;

import androidx.appcompat.app.AppCompatActivity;


import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.hardware.Camera;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.util.Log;
import android.widget.CompoundButton;
import android.widget.Switch;

import static java.lang.Thread.sleep;


public class MainActivity extends AppCompatActivity  {
    private Switch swOnOff;
    //flag to detect flash is on or off
    
   


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        init();
    }

    private void init() {
        swOnOff = findViewById(R.id.swOnOff);
        ajouterEcouteurs();

        Context context = this;
        


    }

    private void ajouterEcouteurs() {
        swOnOff.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                onOff(isChecked);
            }
        });
    }

    private void onOff(boolean isChecked) {
        
    }

   


}
