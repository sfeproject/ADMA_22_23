package acc.com.magapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.animation.Animation;
import android.view.animation.RotateAnimation;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private Button btnTourner;
    private ImageView imgCompass;
    private TextView tvOrient;
    private TextView tvMag;
    private float dernierAngle;
    private float angleTest;

   

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        init();
    }

    private void init() {
        btnTourner = (Button) findViewById(R.id.btnTourner);
        imgCompass = (ImageView) findViewById(R.id.imgCompass);
        tvOrient=(TextView)findViewById(R.id.tvOrient) ;
        tvMag=(TextView)findViewById(R.id.tvMag) ;
        dernierAngle = 0;
        angleTest = 0;

      

        ajouterEcouteur();

    }

    private void ajouterEcouteur() {
        btnTourner.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                tourner30();

            }
        });

    }

   

    protected void tourner30() {
        angleTest += 30;
        if (angleTest > 360)
            angleTest = 30;
        tourner(angleTest);

    }

    private void tourner(float angle) {

        // create a rotation animation (reverse turn degree degrees)

        RotateAnimation ra = new RotateAnimation(

                dernierAngle,

                angle,

                Animation.RELATIVE_TO_SELF, 0.5f,

                Animation.RELATIVE_TO_SELF,

                0.5f);

        // how long the animation will take place

        ra.setDuration(210);

        // set the animation after the end of the reservation status

        ra.setFillAfter(true);

        // Start the animation

        imgCompass.startAnimation(ra);

        dernierAngle = angle;

    }

}
