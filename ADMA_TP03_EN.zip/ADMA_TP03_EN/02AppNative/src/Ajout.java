package bib.com.gestionbibjson;





import android.app.Activity;

import android.os.Bundle;

import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;


public class Ajout extends Activity {
	private EditText edTitre;
	private EditText edNbPage;
	private Button btnAjouter;
	private Button btnRetour;

	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.ajout);
		init();
	}

	private void init() {
		edTitre = (EditText) findViewById(R.id.edTitre1);
		edNbPage = (EditText) findViewById(R.id.edNbPage1);
		btnAjouter = (Button) findViewById(R.id.btnAjouter);
		btnRetour = (Button) findViewById(R.id.btnRetour);
		ajouterEcouteur();
	}

	private void ajouterEcouteur() {
		btnAjouter.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				ajouterLivre();
			}
		});
		btnRetour.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				retourner();
			}
		});
	}

	protected void retourner() {
		finish();

	}

	protected void ajouterLivre() {








	}

}
