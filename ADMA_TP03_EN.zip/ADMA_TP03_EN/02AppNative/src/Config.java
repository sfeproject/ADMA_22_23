package bib.com.gestionbibjson;

public class Config {
	public static final String URL = "http://10.0.2.2:80/JSON_PHP_Bib/bib/";
}
