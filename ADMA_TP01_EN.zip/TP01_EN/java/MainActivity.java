package com.contact;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private static final int ACTION_AJOUT = 1;
    private static final int ACTION_MODIFICATION = 1;
    private static final int ACTION_SUPPRESSION = 1;
    private TextView tvNbContact;
    private Button btnAjout;
    private Button btnSuppression;
    private EditText edFiltre;
    private ListView lstContact;
    private ArrayAdapter<Contact> adpContact;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initActivity();
    }

    private void initActivity() {
        tvNbContact=findViewById(R.id.tvNbContacts);
        btnAjout=findViewById(R.id.btnAjout);
        btnSuppression=findViewById(R.id.btnSuppression);
        edFiltre=findViewById(R.id.edFiltre);
        lstContact=findViewById(R.id.lstContact);
        adpContact=new ArrayAdapter<Contact>(this, android.R.layout.simple_list_item_1);
        lstContact.setAdapter(adpContact);
        remplir();
        ajouterEcouteurs();
    }

    private void ajouterEcouteurs() {
       
    }
  
}